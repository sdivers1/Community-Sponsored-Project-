﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TRPR.Data.TRPRMigrations
{
    public partial class Review : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Reviews",
                schema: "TRPR",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SubmissionID = table.Column<int>(nullable: true),
                    CommentsID = table.Column<int>(nullable: true),
                    StatusID1 = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reviews", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Reviews_Comments_CommentsID",
                        column: x => x.CommentsID,
                        principalSchema: "TRPR",
                        principalTable: "Comments",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reviews_Statuses_StatusID1",
                        column: x => x.StatusID1,
                        principalSchema: "TRPR",
                        principalTable: "Statuses",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reviews_Submissions_SubmissionID",
                        column: x => x.SubmissionID,
                        principalSchema: "TRPR",
                        principalTable: "Submissions",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Reviews_CommentsID",
                schema: "TRPR",
                table: "Reviews",
                column: "CommentsID");

            migrationBuilder.CreateIndex(
                name: "IX_Reviews_StatusID1",
                schema: "TRPR",
                table: "Reviews",
                column: "StatusID1");

            migrationBuilder.CreateIndex(
                name: "IX_Reviews_SubmissionID",
                schema: "TRPR",
                table: "Reviews",
                column: "SubmissionID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Reviews",
                schema: "TRPR");
        }
    }
}
