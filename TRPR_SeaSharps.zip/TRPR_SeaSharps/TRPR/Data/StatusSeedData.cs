﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TRPR.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace TRPR.Data
{
    public static class StatusSeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new TRPRContext(serviceProvider.GetRequiredService<DbContextOptions<TRPRContext>>()))
            {
                if (!context.Statuses.Any())
                {
                    context.Statuses.AddRange(
                        new Status
                        {
                            StatusName = "Pending"
                        },
                        new Status
                        {
                            StatusName = "Reviewed"
                        },
                        new Status
                        {
                            StatusName = "Awaiting Response"
                        },
                        new Status
                        {
                            StatusName = "Accepted"
                        },
                        new Status
                        {
                            StatusName = "Accepted With Revisions"
                        },
                        new Status
                        {
                            StatusName = "Rejected"
                        },
                        new Status
                        {
                            StatusName = "Rejected With Revisions."
                        }
                        );
                        context.SaveChanges();
                }
            }
        }
    }
}
