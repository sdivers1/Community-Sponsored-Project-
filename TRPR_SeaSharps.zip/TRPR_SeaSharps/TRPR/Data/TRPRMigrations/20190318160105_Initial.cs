﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TRPR.Data.TRPRMigrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PersPapers_Person_PersonID",
                schema: "TRPR",
                table: "PersPapers");

            migrationBuilder.DropTable(
                name: "FileContent",
                schema: "TRPR");

            migrationBuilder.DropTable(
                name: "Files",
                schema: "TRPR");

            migrationBuilder.AddForeignKey(
                name: "FK_PersPapers_Person_PersonID",
                schema: "TRPR",
                table: "PersPapers",
                column: "PersonID",
                principalSchema: "TRPR",
                principalTable: "Person",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PersPapers_Person_PersonID",
                schema: "TRPR",
                table: "PersPapers");

            migrationBuilder.CreateTable(
                name: "Files",
                schema: "TRPR",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatedBy = table.Column<string>(maxLength: 256, nullable: true),
                    CreatedOn = table.Column<DateTime>(nullable: true),
                    Description = table.Column<string>(maxLength: 1024, nullable: true),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    SubmissionID = table.Column<int>(nullable: false),
                    UpdatedBy = table.Column<string>(maxLength: 256, nullable: true),
                    UpdatedOn = table.Column<DateTime>(nullable: true),
                    fileName = table.Column<string>(maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Files", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Files_Submissions_SubmissionID",
                        column: x => x.SubmissionID,
                        principalSchema: "TRPR",
                        principalTable: "Submissions",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "FileContent",
                schema: "TRPR",
                columns: table => new
                {
                    FileContentID = table.Column<int>(nullable: false),
                    Content = table.Column<byte[]>(nullable: true),
                    MimeType = table.Column<string>(maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileContent", x => x.FileContentID);
                    table.ForeignKey(
                        name: "FK_FileContent_Files_FileContentID",
                        column: x => x.FileContentID,
                        principalSchema: "TRPR",
                        principalTable: "Files",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Files_SubmissionID",
                schema: "TRPR",
                table: "Files",
                column: "SubmissionID");

            migrationBuilder.AddForeignKey(
                name: "FK_PersPapers_Person_PersonID",
                schema: "TRPR",
                table: "PersPapers",
                column: "PersonID",
                principalSchema: "TRPR",
                principalTable: "Person",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
