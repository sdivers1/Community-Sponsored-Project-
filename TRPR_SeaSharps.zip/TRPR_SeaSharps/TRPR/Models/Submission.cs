﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TRPR.Models
{
    public class Submission
    {
        public Submission()
        {
            this.PersPapers = new HashSet<PersPaper>();
            //this.SubKeys = new HashSet<SubKeys>();
            //this.Files = new HashSet<AFile>();
            this.Reviews = new HashSet<Review>();
        }

        public int ID { get; set; }

        [Required(ErrorMessage = "You cannot leave title blank.")]
        [StringLength(150, ErrorMessage = "Title cannot be more than 150 characters long.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "You cannot leave type blank.")]
        [StringLength(100, ErrorMessage = "The type cannot be more than 100 characters long.")]
        public string Type { get; set; }

        [Display(Name = "Abstract")]
        [Required(ErrorMessage = "You cannot leave description blank.")]
        [StringLength(250, ErrorMessage = "The description cannot be more than 250 characters long.")]
        public string Description { get; set; }

        [Display(Name = "Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? SubDate { get; set; }

        public virtual ICollection<PersPaper> PersPapers { get; set; }

        [Display(Name = "Keywords")]
        [Range(1,int.MaxValue,ErrorMessage ="You must select a keyword for this this Submission.")]
        public int KeywordID { get; set; }
        public virtual Keyword Keyword { get; set; }

        //public virtual ICollection<SubKeys> SubKeys { get; set; }

        //Added to hold related files
        //public ICollection<AFile> Files { get; set; }
        public ICollection<Review> Reviews { get; set; }    

    }
}
