﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using TRPR.Models;

namespace TRPR.Data
{
    public class TRPRContext : DbContext
    {
        public TRPRContext (DbContextOptions<TRPRContext> options)
            : base(options)
        {
            UserName = "SeedData";
        }

        public TRPRContext(DbContextOptions<TRPRContext> options, IHttpContextAccessor httpContextAccessor)
            : base(options)
        {
            _httpContextAccessor = httpContextAccessor;
            UserName = _httpContextAccessor.HttpContext?.User.Identity.Name;
            UserName = (UserName == null) ? "Unknown" : UserName;
        }

        private readonly IHttpContextAccessor _httpContextAccessor;

        public string UserName
        {
            get; private set;
        }

        public DbSet<Person> Person { get; set; }
        public DbSet<Submission> Submissions { get; set; }
        public DbSet<Comments> Comments { get; set; }
        public DbSet<Keyword> Keywords { get; set; }
        public DbSet<Status> Statuses { get; set; }
        public DbSet<PersPaper> PersPapers { get; set; }
        ////public DbSet<SubKeys> SubKeys { get; set; }
        //public DbSet<AFile> Files { get; set; }
        public DbSet<Review> Reviews { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("TRPR");

            modelBuilder.Entity<Person>()
            .HasIndex(a => new { a.Email })
            .IsUnique();

            //modelBuilder.Entity<SubKeys>()
            //  .HasKey(t => new { t.SubID, t.KeywordID });

            modelBuilder.Entity<PersPaper>()
              .HasKey(t => new { t.PersonID, t.SubID });

            modelBuilder.Entity<Keyword>()
                .HasMany<Submission>(s => s.Submissions)
                .WithOne(k => k.Keyword)
                .HasForeignKey(k => k.KeywordID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Person>()
            .HasMany<PersPaper>(p => p.PersPapers)
            .WithOne(c => c.Person)
            .HasForeignKey(c => c.PersonID)
            .OnDelete(DeleteBehavior.Restrict);




        }
    }
}
