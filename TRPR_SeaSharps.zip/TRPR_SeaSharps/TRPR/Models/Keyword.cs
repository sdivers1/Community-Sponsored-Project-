﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TRPR.Models
{
    public class Keyword
    {
        public Keyword()
        {
            this.Submissions = new HashSet<Submission>();
            //this.SubKeys = new HashSet<SubKeys>();
        }
        public int ID { get; set; }
        [Required(ErrorMessage = "You cannot leave keyword blank.")]
        [StringLength(30, ErrorMessage = "Keyword cannot be more than 30 characters long.")]
        public string Keywords { get; set; }

        public virtual ICollection<Submission> Submissions { get; set; }
        //public virtual ICollection<SubKeys> SubKeys { get; set; }



    }
}
