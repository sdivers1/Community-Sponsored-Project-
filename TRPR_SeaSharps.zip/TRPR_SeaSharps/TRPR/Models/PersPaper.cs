﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TRPR.Models
{
    public class PersPaper
    {
        public int ID { get; set; }

        public int SubID { get; set; }
        public virtual Submission Submission { get; set; }  

        public int PersonID { get; set; }
        public virtual Person Person { get; set; }  

    
    }
}
