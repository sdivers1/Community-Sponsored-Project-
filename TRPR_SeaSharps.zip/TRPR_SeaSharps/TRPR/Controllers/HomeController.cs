﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using TRPR.Models;

namespace TRPR.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration configuration;

        public HomeController(IConfiguration config)
        {
            this.configuration = config;
        }

        public IActionResult Index()
        {
            string connectionstring = configuration.GetConnectionString("DefaultConnection");
            SqlConnection connection = new SqlConnection(connectionstring);

            if (User.IsInRole("AssociateEditors"))
            {
                return View("IndexAEditor");
            }
            else if (User.IsInRole("Editor"))
            {
                return View("IndexEditor");
            }
            else if (User.IsInRole("Authors"))
            {
                connection.Open();                   
                    SqlCommand com = new SqlCommand("Select count(*) From [dbo].[AspNetRoles]", connection);
                    var count = (int)com.ExecuteScalar();
                    //ViewData["Data"] = count;
                    //SqlCommand com = new SqlCommand("SELECT * FROM [TRPR].[Submissions]JOIN [TRPR].[PersPapers] ON [TRPR].[PersPapers].SubmissionID = [TRPR].[Submissions].ID WHERE [TRPR].[PersPapers].PersonID = 1"
                    //                                , connection);
                    //var count = (int)com.ExecuteScalar();
                    ViewData["Data"] = count;
                connection.Close();
                return View("IndexAuthor");
            }
            return View("signIn");
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
