﻿    using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TRPR.Models
{
    public class Comments
    {
        public Comments()
        {
            this.Reviews = new HashSet<Review>();
        }
        public int ID { get; set; }

        [Display(Name = "Editor's Comments")]
        [StringLength(250, ErrorMessage = "Editor's Comments cannot be more than 250 characters long.")]
        public string CommentEditor { get; set; }

        [Display(Name = "Assocaite Editor's 1 Comments")]
        [StringLength(250, ErrorMessage = "Associate Editor's Comments cannot be more than 250 characters long.")]
        public string CommentAssociate1 { get; set; }

        [Display(Name = "Assocaite Editor's 2 Comments")]
        [StringLength(250, ErrorMessage = "Associate Editor's Comments cannot be more than 250 characters long.")]
        public string CommentAssociate2 { get; set; }

        public ICollection<Review> Reviews { get; set; }
    }
}
