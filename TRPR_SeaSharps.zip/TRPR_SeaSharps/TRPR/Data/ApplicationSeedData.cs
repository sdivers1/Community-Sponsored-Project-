﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;


namespace TRPR.Data
{
    public static class ApplicationSeedData
    {
        public static async Task SeedAsync(ApplicationDbContext context, IServiceProvider serviceProvider)
        {
            var RoleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            string[] roleNames = { "Editor", "AssociateEditors", "Authors"};
            IdentityResult roleResult;
            foreach (var roleName in roleNames)
            {
                var roleExist = await RoleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    roleResult = await RoleManager.CreateAsync(new IdentityRole(roleName));
                }
                var userManager = serviceProvider.GetRequiredService<UserManager<IdentityUser>>();
                if (userManager.FindByEmailAsync("editor@outlook.com").Result == null)
                {
                    IdentityUser user = new IdentityUser
                    {
                        UserName = "editor@outlook.com",
                        Email = "editor@outlook.com"
                    };

                    IdentityResult result = userManager.CreateAsync(user, "password").Result;

                    if (result.Succeeded)
                    {
                        userManager.AddToRoleAsync(user, "Editor").Wait();
                    }
                }
                if (userManager.FindByEmailAsync("associate1@outlook.com").Result == null)
                {
                    IdentityUser user = new IdentityUser
                    {
                        UserName = "associate1@outlook.com",
                        Email = "associate1@outlook.com"
                    };

                    IdentityResult result = userManager.CreateAsync(user, "password").Result;

                    if (result.Succeeded)
                    {
                        userManager.AddToRoleAsync(user, "AssociateEditors").Wait();
                    }

                }
                if (userManager.FindByEmailAsync("associate2@outlook.com").Result == null)
                {
                    IdentityUser user = new IdentityUser
                    {
                        UserName = "associate2@outlook.com",
                        Email = "associate2@outlook.com"
                    };

                    IdentityResult result = userManager.CreateAsync(user, "password").Result;

                    if (result.Succeeded)
                    {
                        userManager.AddToRoleAsync(user, "AssociateEditors").Wait();
                    }
                }
                if (userManager.FindByEmailAsync("author@outlook.com").Result == null)
                {
                    IdentityUser user = new IdentityUser
                    {
                        UserName = "author@outlook.com",
                        Email = "author@outlook.com"
                    };

                    IdentityResult result = userManager.CreateAsync(user, "password").Result;

                    if (result.Succeeded)
                    {
                        userManager.AddToRoleAsync(user, "Authors").Wait();
                    }
                }
            }
        }
    }
}
