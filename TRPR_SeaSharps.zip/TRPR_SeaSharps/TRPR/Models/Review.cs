﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TRPR.Models
{
    public class Review
    {
        public int ID { get; set; }


        public int SubID;
        public virtual Submission Submission { get; set; } 

        public int CommentID;
        public virtual Comments Comments { get; set; }

        public int StatusID; 
        public virtual Status Status { get; set; }

    }
}
