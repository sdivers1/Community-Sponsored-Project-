﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TRPR.Models
{
    public class Status
    {
        public Status()
        {
            this.Reviews = new HashSet<Review>();
        }

        public int ID { get; set; }

        [Display(Name = "Status")]
        [Required(ErrorMessage = "You cannot leave Status blank.")]
        [StringLength(30, ErrorMessage = "Status cannot be more than 30 characters long.")]
        public string StatusName { get; set; }

        public ICollection<Review> Reviews { get; set; }    
    }
}
