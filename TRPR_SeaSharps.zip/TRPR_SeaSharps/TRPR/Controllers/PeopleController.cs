﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TRPR.Data;
using TRPR.Models;
using TRPR.Utilities;

namespace TRPR.Controllers
{
    public class PersonController : Controller
    {
        private readonly TRPRContext _context;

        public PersonController(TRPRContext context)
        {
            _context = context;
        }

        // GET: PersonProfile
        public IActionResult Index()
        {
            return RedirectToAction(nameof(Details));
        }

        // GET: PersonProfile/Details/5
        public async Task<IActionResult> Details()
        {

            var Person = await _context.Person
                .Where(c => c.Email == User.Identity.Name)
                .FirstOrDefaultAsync();
            if (Person == null)
            {
                return RedirectToAction(nameof(Create));
            }

            return View(Person);
        }

        // GET: PersonProfile/Create
        public IActionResult Create()
        {

            return View();
        }

        // POST: PersonProfile/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,FirstName,LastName,Phone,Email,Area,Bio")] Person Person)
        {
            Person.Email = User.Identity.Name;
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(Person);
                    await _context.SaveChangesAsync();
                    UpdateUserNameCookie(Person.FullName);
                    return RedirectToAction(nameof(Details));
                }
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            return View(Person);
        }

        // GET: PersonProfile/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Person = await _context.Person
                .Where(c => c.Email == User.Identity.Name)
                .FirstOrDefaultAsync();
            if (Person == null)
            {
                return NotFound();
            }
            return View(Person);
        }

        // POST: PersonProfile/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Byte[] RowVersion)
        {
            var PersonToUpdate = await _context.Person
                .FirstOrDefaultAsync(m => m.ID == id);

            if (await TryUpdateModelAsync<Person>(PersonToUpdate, "",
                c => c.FirstName, c => c.LastName, c => c.Phone))
            {
                try
                {
                    //Put the original RowVersion value in the OriginalValues collection for the entity
                    _context.Entry(PersonToUpdate).Property("RowVersion").OriginalValue = RowVersion;
                    _context.Update(PersonToUpdate);
                    await _context.SaveChangesAsync();
                    UpdateUserNameCookie(PersonToUpdate.FullName);
                    return RedirectToAction(nameof(Details));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PersonExists(PersonToUpdate.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        ModelState.AddModelError("", "Unable to save changes. The record you attempted to edit "
                                + "was modified by another user after you received your values.  You need to go back and try your edit again.");
                    }
                }
            }
            return View(PersonToUpdate);
        }

        private void UpdateUserNameCookie(string userName)
        {
            CookieHelper.CookieSet(HttpContext, "userName", userName, 960);
        }

        private bool PersonExists(int id)
        {
            return _context.Person.Any(e => e.ID == id);
        }
    }
}
